import { enhancer } from "./LoginForm.enhancer";
import { LoginForm } from "./LoginForm";

export const LoginFormContainer = enhancer(LoginForm);

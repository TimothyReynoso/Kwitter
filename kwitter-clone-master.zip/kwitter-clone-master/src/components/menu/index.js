import { enhancer } from "./Menu.enhancer";
import { Menu } from "./Menu";

export const MenuContainer = enhancer(Menu);

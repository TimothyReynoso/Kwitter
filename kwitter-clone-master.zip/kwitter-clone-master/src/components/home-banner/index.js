import React from 'react'
import './home-banner.css'

export const HomeBanner = () => {
    return (
        <div className="home_banner">
            <div className="logo">Leafy</div>
        </div>
    )
}
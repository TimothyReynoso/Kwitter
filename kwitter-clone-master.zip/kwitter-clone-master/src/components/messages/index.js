import { enhancer } from "./Messages.enhancer";
import FeedPage from "./feed";

export const MessageContainer = enhancer(FeedPage); 
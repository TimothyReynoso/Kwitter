import { enhancer } from './Register.enhancer';
import { Register } from './Register';

export const RegisterFormContainer = enhancer(Register);

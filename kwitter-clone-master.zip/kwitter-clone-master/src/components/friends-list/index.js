import { enhancer } from "./Friends_List.enhancer";
import { FriendsList } from "./Friends_List";

export const FriendsListEnhanced = enhancer(FriendsList);

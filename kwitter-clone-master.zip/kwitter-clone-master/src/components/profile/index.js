import { enhancer } from "./Profile.enhancer";
import { Profile } from "./Profile";

export const ProfileContainer = enhancer(Profile);
